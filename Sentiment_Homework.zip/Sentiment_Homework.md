

```python
# find the twitter handle for 

# BBC, CBS, CNN, Fox, and New York times

# @bbcnews, @cbsnews, @cnn, @foxnews, @nytimes


```


```python
# Dependencies
import tweepy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
from config import (consumer_key, 
                    consumer_secret, 
                    access_token, 
                    access_token_secret)

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
# figure out how to loop through and not run each search independently
# this works for now, but not the best code
# i think i need to nest another for loop for each news twitter handle in the list of twitter handles
```


```python
# Target Account
target_user = "@bbcnews"

# Counter
counter = 1

# Variables for holding sentiments
sentiments = []

# Variable for max_id
oldest_tweet = None

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, max_id = oldest_tweet)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
#         print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        msg = tweet["text"]
        
        tweets_ago = counter
           
        # Get Tweet ID, subtract 1, and assign to oldest_tweet
        oldest_tweet = tweet['id'] - 1
        
        # Add sentiments for each tweet into a list
        sentiments.append({"User": target_user,
                           "Date": tweet["created_at"], 
                           "Compound": compound,
                           "Positive": pos,
                           "Negative": neu,
                           "Neutral": neg,
                           "Tweets Ago": counter,
                           "msg": msg,
                           "color": 'red'})
        
        # Add to counter 
        counter += 1

# Convert sentiments to DataFrame
sentiments_bbc = pd.DataFrame.from_dict(sentiments)
# sentiments_bbc.head()
```


```python
# Target Account
target_user = "@cbsnews"

# Counter
counter = 1

# Variables for holding sentiments
sentiments = []

# Variable for max_id
oldest_tweet = None

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, max_id = oldest_tweet)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
#         print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        msg = tweet["text"]
            
        tweets_ago = counter
           
        # Get Tweet ID, subtract 1, and assign to oldest_tweet
        oldest_tweet = tweet['id'] - 1
        
        # Add sentiments for each tweet into a list
        sentiments.append({"User": target_user,
                           "Date": tweet["created_at"], 
                           "Compound": compound,
                           "Positive": pos,
                           "Negative": neu,
                           "Neutral": neg,
                           "Tweets Ago": counter,
                           "msg": msg,
                           "color": 'yellow'})
        
        # Add to counter 
        counter += 1

# Convert sentiments to DataFrame
sentiments_cbs = pd.DataFrame.from_dict(sentiments)
# sentiments_cbs.head()

```


```python
# Target Account
target_user = "@cnn"

# Counter
counter = 1

# Variables for holding sentiments
sentiments = []

# Variable for max_id
oldest_tweet = None

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, max_id = oldest_tweet)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
#         print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        msg = tweet["text"]
            
        tweets_ago = counter
           
        # Get Tweet ID, subtract 1, and assign to oldest_tweet
        oldest_tweet = tweet['id'] - 1
        
        # Add sentiments for each tweet into a list
        sentiments.append({"User": target_user,
                           "Date": tweet["created_at"], 
                           "Compound": compound,
                           "Positive": pos,
                           "Negative": neu,
                           "Neutral": neg,
                           "Tweets Ago": counter,
                           "msg": msg,
                           "color": 'blue'})
        
        # Add to counter 
        counter += 1

# Convert sentiments to DataFrame
sentiments_cnn = pd.DataFrame.from_dict(sentiments)
# sentiments_cnn.head()
```


```python
# Target Account
target_user = "@foxnews"

# Counter
counter = 1

# Variables for holding sentiments
sentiments = []

# Variable for max_id
oldest_tweet = None

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, max_id = oldest_tweet)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
#         print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        msg = tweet["text"]
            
        tweets_ago = counter
           
        # Get Tweet ID, subtract 1, and assign to oldest_tweet
        oldest_tweet = tweet['id'] - 1
        
        # Add sentiments for each tweet into a list
        sentiments.append({"User": target_user,
                           "Date": tweet["created_at"], 
                           "Compound": compound,
                           "Positive": pos,
                           "Negative": neu,
                           "Neutral": neg,
                           "Tweets Ago": counter,
                           "msg": msg,
                           "color": 'green'})
        
        # Add to counter 
        counter += 1

# Convert sentiments to DataFrame
sentiments_fox = pd.DataFrame.from_dict(sentiments)
# sentiments_fox.head()
```


```python
# Target Account
target_user = "@nytimes"

# Counter
counter = 1

# Variables for holding sentiments
sentiments = []

# Variable for max_id
oldest_tweet = None

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, max_id = oldest_tweet)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
#         print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        msg = tweet["text"]
            
        tweets_ago = counter
           
        # Get Tweet ID, subtract 1, and assign to oldest_tweet
        oldest_tweet = tweet['id'] - 1
        
        # Add sentiments for each tweet into a list
        sentiments.append({"User": target_user,
                           "Date": tweet["created_at"], 
                           "Compound": compound,
                           "Positive": pos,
                           "Negative": neu,
                           "Neutral": neg,
                           "Tweets Ago": counter,
                           "msg": msg,
                           "color": 'orange'})
        
        # Add to counter 
        counter += 1

# Convert sentiments to DataFrame
sentiments_nyt = pd.DataFrame.from_dict(sentiments)
# sentiments_nyt.head()
```


```python
frames = [sentiments_nyt, sentiments_fox, sentiments_cnn, sentiments_cbs, sentiments_bbc]
agg_data = pd.concat(frames)
# agg_data.head()
```


```python
agg_data.to_csv('agg_data.csv') # checks out as 500 rows
```


```python
# Target Search Term
target_terms = ("@bbcnews", "@cbsnews", "@cnn", "@foxnews", "@nytimes")

# "Real Person" Filters
min_tweets = 5
max_tweets = 10000
max_followers = 2500
max_following = 2500
lang = "en"

# List to hold results
results_list = []

# Loop through all target users
for target in target_terms:

    # Variable for holding the oldest tweet
    oldest_tweet = None

    # Variables for holding sentiments
    compound_list = []
    positive_list = []
    negative_list = []
    neutral_list = []

    # Loop through 10 times
    for x in range(10):

        # Run search around each tweet
        public_tweets = api.search(
            target, count=100, result_type="recent", max_id=oldest_tweet)

        # Loop through all tweets
        for tweet in public_tweets["statuses"]:

            # Use filters to check if user meets conditions
            if (tweet["user"]["followers_count"] < max_followers
                and tweet["user"]["statuses_count"] > min_tweets
                and tweet["user"]["statuses_count"] < max_tweets
                and tweet["user"]["friends_count"] < max_following
                and tweet["user"]["lang"] == lang):

                # Run Vader Analysis on each tweet
                results = analyzer.polarity_scores(tweet["text"])
                compound = results["compound"]
                pos = results["pos"]
                neu = results["neu"]
                neg = results["neg"]

                # Add each value to the appropriate list
                compound_list.append(compound)
                positive_list.append(pos)
                negative_list.append(neg)
                neutral_list.append(neu)
                
            # Set the new oldest_tweet value
            oldest_tweet = tweet["id"] - 1

    # Store the Average Sentiments
    sentiment = {
        "User": target,
        "Compound": np.mean(compound_list),
        "Positive": np.mean(positive_list),
        "Neutral": np.mean(negative_list),
        "Negative": np.mean(neutral_list),
        "Tweet Count": len(compound_list)
    }

    # Print the Sentiments
#     print(sentiment)
#     print()
    
    # Append airline results to 'results_list'
    results_list.append(sentiment)


```


```python
agg_df = pd.DataFrame(results_list).set_index("User").round(3)
agg_df['color'] = ('red','yellow','blue','green','orange')
# agg_df.head()
agg_df.to_csv("BarChartData.csv")
```


```python
import datetime

fig, ax = plt.subplots(figsize=(11,8))

for key, grp in agg_data.groupby(['User']):
    ax = grp.plot(ax=ax, linestyle='none', x='Tweets Ago', y='Compound', marker = 'o', label=key)
    ax.invert_xaxis()
    ax.set_ylabel("Compound Sentiment Score")
    ax.set_title("Sentiment Analysis of Media Tweets "+str(datetime.date.today()))
plt.legend(loc='best')

plt.show()

plt.savefig('0_Sentiment_Analysis_100_Tweets.png')
```


![png](output_12_0.png)



    <matplotlib.figure.Figure at 0x1eb1dd94fd0>



```python
color = agg_df.color
ax=agg_df.plot(kind='bar',y='Compound',color=color,legend=False,figsize=(11,8))
ax.set_xlabel("News Station")
ax.set_ylabel("Compound Sentiment Score")
ax.set_title("Overall Media Sentiment based on Twitter "+str(datetime.date.today()))
plt.show()
plt.savefig('1_Overall_Sentiment_100_Tweets.png')
```


![png](output_13_0.png)



    <matplotlib.figure.Figure at 0x1eb1ca25a20>

